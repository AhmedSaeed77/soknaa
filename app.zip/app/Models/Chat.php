<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Chat extends Model
{
    use HasFactory;

    protected $table = 'chats';
    protected $guarded = [];


    public function fromUser()
    {
        return $this->belongsTo(User::class, 'from_user');
    }
    
    
    public function order()
    {
        return $this->belongsTo(Order::class,'order_id');
    }
}
